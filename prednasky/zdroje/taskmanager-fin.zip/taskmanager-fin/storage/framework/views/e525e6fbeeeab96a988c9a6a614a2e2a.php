<?php $__env->startSection('content'); ?>
    <?php if(Session::has('message')): ?>
        <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
    <?php endif; ?>
    <h1>Zoznam úloh</h1>
    <table class="table">
        <thead class="thead-light">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Názov</th>
                <th scope="col">Opis</th>
                <th scope="col">Autor</th>
                <th scope="col">Dátum vytvorenia</th>
                <th scope="col">Akcia</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($task->id); ?> <?php echo e(App::currentLocale()); ?></th>
                    <td><a href="/tasks/<?php echo e($task->id); ?>"><?php echo e($task->title); ?></a></td>
                    <td><?php echo e($task->description); ?></td>
                    <td><?php echo e($task->author->name); ?></td>
                    <td><?php echo e($task->created_at->toFormattedDateString()); ?></td>
                    <td>
                        <div class="btn-group" role="group">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $task)): ?>
                                <a class="btn btn-warning" href="<?php echo e(URL::to('tasks/' . $task->id . '/edit')); ?>">
                                    Editovať
                                </a>&nbsp;&nbsp;
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $task)): ?>
                                <form action="<?php echo e(url('tasks', [$task->id])); ?>" method="POST">
                                    <input type="hidden" name="_method" value="DELETE">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <input type="submit" class="btn btn-danger" value="Vymazať" />
                                </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/eduardkuric/DEV/taskmanager/resources/views/tasks/index.blade.php ENDPATH**/ ?>